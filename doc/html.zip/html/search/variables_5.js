var searchData=
[
  ['gdesc_910',['gdesc',['../struct__Space.html#af16889f2e832aaf4cd811749f509cabe',1,'_Space']]]
];

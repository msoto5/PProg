var searchData=
[
  ['take_967',['TAKE',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50ca7405647410e343caba1bf383e83d4f5f',1,'command.h']]]
];

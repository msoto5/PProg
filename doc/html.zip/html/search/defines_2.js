var searchData=
[
  ['fd_5fid_5fenemy_973',['FD_ID_ENEMY',['../types_8h.html#a9f4cebe7ae2aa6cf565c503bd53e9768',1,'types.h']]],
  ['fd_5fid_5fobj_974',['FD_ID_OBJ',['../types_8h.html#a6144fdeac03045d36d1f4b3d4dcd2144',1,'types.h']]],
  ['fd_5fid_5fplayer_975',['FD_ID_PLAYER',['../types_8h.html#a05bfc4778b96c8731994dbabd196d8c4',1,'types.h']]],
  ['fd_5fid_5fspace_976',['FD_ID_SPACE',['../types_8h.html#a61e0e116c0039e180733516dbab230c4',1,'types.h']]],
  ['first_5fspace_977',['FIRST_SPACE',['../space_8h.html#a088cbe7c6f78264d46c2624194c5c680',1,'space.h']]]
];

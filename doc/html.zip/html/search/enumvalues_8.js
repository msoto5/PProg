var searchData=
[
  ['open_965',['OPEN',['../link_8h.html#ab0ce7873e5a1bd8bc18fafaaed449b24a0e0143636c29971736eab47415868eae',1,'link.h']]]
];

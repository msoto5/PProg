var searchData=
[
  ['spaces_927',['spaces',['../struct__Game.html#ad5f218aa97ec196cf2c13d4832f6bc77',1,'_Game']]],
  ['start_928',['start',['../struct__Link.html#ad573dac52288be4d8fc859c91e26e516',1,'_Link']]],
  ['status_929',['status',['../struct__Link.html#a3e63ab2bffef082dfdd87b4c7c57aca2',1,'_Link']]]
];

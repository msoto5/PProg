var searchData=
[
  ['player_926',['player',['../struct__Game.html#a9317e55e7d847c5953c2ef7f53d8049b',1,'_Game']]]
];

var searchData=
[
  ['obj_5fcreate_190',['obj_create',['../object_8c.html#a1196be6af8524bec98758a054f146c66',1,'obj_create(Id id):&#160;object.c'],['../object_8h.html#a1196be6af8524bec98758a054f146c66',1,'obj_create(Id id):&#160;object.c']]],
  ['obj_5fdestroy_191',['obj_destroy',['../object_8c.html#a9f0570389f84ae8db6264cae9c4e9080',1,'obj_destroy(Object *obj):&#160;object.c'],['../object_8h.html#a9f0570389f84ae8db6264cae9c4e9080',1,'obj_destroy(Object *obj):&#160;object.c']]],
  ['obj_5fget_5fdescription_192',['obj_get_description',['../object_8c.html#accee14305e369faeb245c075cedb7f42',1,'obj_get_description(Object *obj):&#160;object.c'],['../object_8h.html#accee14305e369faeb245c075cedb7f42',1,'obj_get_description(Object *obj):&#160;object.c']]],
  ['obj_5fget_5fid_193',['obj_get_id',['../object_8c.html#a89225b78ffdf02a89480adc75be34739',1,'obj_get_id(Object *obj):&#160;object.c'],['../object_8h.html#a89225b78ffdf02a89480adc75be34739',1,'obj_get_id(Object *obj):&#160;object.c']]],
  ['obj_5fget_5flocation_194',['obj_get_location',['../object_8c.html#a2bd0352f6023deb89b2264164caba8bb',1,'obj_get_location(Object *obj):&#160;object.c'],['../object_8h.html#a2bd0352f6023deb89b2264164caba8bb',1,'obj_get_location(Object *obj):&#160;object.c']]],
  ['obj_5fget_5fname_195',['obj_get_name',['../object_8c.html#a9592df618edfeffbb0cf0ae098e06ac7',1,'obj_get_name(Object *obj):&#160;object.c'],['../object_8h.html#a9592df618edfeffbb0cf0ae098e06ac7',1,'obj_get_name(Object *obj):&#160;object.c']]],
  ['obj_5fname_5flen_196',['OBJ_NAME_LEN',['../object_8h.html#a772c9b6f4756eb0380881a8e5c8636ab',1,'object.h']]],
  ['obj_5fprint_197',['obj_print',['../object_8c.html#a614b6346bae24b7f4dd8f03c6baae320',1,'obj_print(Object *obj):&#160;object.c'],['../object_8h.html#a614b6346bae24b7f4dd8f03c6baae320',1,'obj_print(Object *obj):&#160;object.c']]],
  ['obj_5fset_5fdescription_198',['obj_set_description',['../object_8c.html#aafbd67c3a3fd911503fd328451eb346c',1,'obj_set_description(Object *obj, char *description):&#160;object.c'],['../object_8h.html#a0a01818cfdd8a79f8fc1f638b77222b0',1,'obj_set_description(Object *obj, char *descripcion):&#160;object.c']]],
  ['obj_5fset_5flocation_199',['obj_set_location',['../object_8c.html#a59da0d71a06d036b835c48d848001528',1,'obj_set_location(Object *obj, Id id):&#160;object.c'],['../object_8h.html#a59da0d71a06d036b835c48d848001528',1,'obj_set_location(Object *obj, Id id):&#160;object.c']]],
  ['obj_5fset_5fname_200',['obj_set_name',['../object_8c.html#aaf03e96213e913c07d16ee11b894675c',1,'obj_set_name(Object *obj, char *name):&#160;object.c'],['../object_8h.html#aaf03e96213e913c07d16ee11b894675c',1,'obj_set_name(Object *obj, char *name):&#160;object.c']]],
  ['obj_5ftest_5fid_201',['obj_test_id',['../object_8c.html#a43d7237985c6fbdc234409f4199536df',1,'obj_test_id(Id id):&#160;object.c'],['../object_8h.html#a43d7237985c6fbdc234409f4199536df',1,'obj_test_id(Id id):&#160;object.c']]],
  ['object_202',['object',['../struct__Game.html#a55f0bd915f898d2b13c39702526a8618',1,'_Game::object()'],['../object_8h.html#a7f8bbcda919b65ce67f92fba08e0212f',1,'Object():&#160;object.h']]],
  ['object_2ec_203',['object.c',['../object_8c.html',1,'']]],
  ['object_2eh_204',['object.h',['../object_8h.html',1,'']]],
  ['object_5ftest_2eh_205',['object_test.h',['../object__test_8h.html',1,'']]],
  ['objects_206',['objects',['../struct__Inventory.html#a478e4b50a62b9e7d5b17e335319faa97',1,'_Inventory::objects()'],['../struct__Space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space::objects()']]],
  ['open_207',['OPEN',['../link_8h.html#ab0ce7873e5a1bd8bc18fafaaed449b24a0e0143636c29971736eab47415868eae',1,'link.h']]]
];

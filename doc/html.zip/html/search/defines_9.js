var searchData=
[
  ['tam_5fgdesc_5fx_993',['TAM_GDESC_X',['../space_8h.html#a950f9cc9e579630a3000a77dd0772b97',1,'space.h']]],
  ['tam_5fgdesc_5fy_994',['TAM_GDESC_Y',['../space_8h.html#a4e076130a30ef97968b0556881dde1e8',1,'space.h']]]
];

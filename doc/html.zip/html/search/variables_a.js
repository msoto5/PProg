var searchData=
[
  ['n_5fids_922',['n_ids',['../struct__Set.html#aff8fb061f3279f176735b4f9fcac2122',1,'_Set']]],
  ['name_923',['name',['../struct__Enemy.html#ae7755e15bd215a285128f211d330b43a',1,'_Enemy::name()'],['../struct__Link.html#a1f2673ab94d00ba7e30fdbd1aadcc907',1,'_Link::name()'],['../struct__Object.html#a54a1f6b77e687fbfeea6d804daa0556c',1,'_Object::name()'],['../struct__Player.html#acd196a1920c07ef52df0d2b564409f22',1,'_Player::name()'],['../struct__Space.html#aa1c9c994c2d16ecf3ef46138685fdfdc',1,'_Space::name()']]]
];

var searchData=
[
  ['_5fdir2i_540',['_dir2i',['../space_8c.html#abb37e060ada509644401fd5624817aa3',1,'space.c']]]
];

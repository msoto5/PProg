var searchData=
[
  ['link_5fname_5flen_978',['LINK_NAME_LEN',['../link_8h.html#a6bb03f4c220dc5e038ca97edfcd29ae9',1,'link.h']]]
];

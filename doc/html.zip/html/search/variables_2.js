var searchData=
[
  ['descript_904',['descript',['../struct__Graphic__engine.html#a414bb888ecce3389c7ce348264758e58',1,'_Graphic_engine']]],
  ['description_905',['description',['../struct__Game.html#a9ae2866ccac9461c4385dbf29f03c4b5',1,'_Game::description()'],['../struct__Object.html#a556e2e37c1461bcaae6492d2101f407d',1,'_Object::description()'],['../struct__Space.html#a2a50aacb78d1d0f65f5b14f94ed81d80',1,'_Space::description()']]],
  ['destination_906',['destination',['../struct__Link.html#aae5a495d4f85697715abe75da7c59cd0',1,'_Link']]],
  ['direction_907',['direction',['../struct__Link.html#a60a439916b9ae8d52e3d0c4c5e48806c',1,'_Link']]]
];

var searchData=
[
  ['player_5fname_5flenght_991',['Player_Name_lenght',['../player_8h.html#aeaa5bbc258c74817a3f698ee0c2658be',1,'player.h']]]
];

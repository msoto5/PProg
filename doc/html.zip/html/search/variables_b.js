var searchData=
[
  ['object_924',['object',['../struct__Game.html#a55f0bd915f898d2b13c39702526a8618',1,'_Game']]],
  ['objects_925',['objects',['../struct__Inventory.html#a478e4b50a62b9e7d5b17e335319faa97',1,'_Inventory::objects()'],['../struct__Space.html#a661ed8b0fc8085b6db70188aa5085625',1,'_Space::objects()']]]
];

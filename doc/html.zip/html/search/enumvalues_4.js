var searchData=
[
  ['inspect_957',['INSPECT',['../command_8h.html#ace19ba2296a74e4aef53304e0934c50caab933f64fcaa285df294e1420f6f1b07',1,'command.h']]],
  ['is_5fenemy_958',['IS_ENEMY',['../game__reader_8h.html#a8633d96cdc0edc3e9ba01fe0b1592815ae4212eb93624ff06c77bf190279be5a7',1,'game_reader.h']]],
  ['is_5fobject_959',['IS_OBJECT',['../game__reader_8h.html#a8633d96cdc0edc3e9ba01fe0b1592815a47a1c9b86adbf017be82f8f370d01610',1,'game_reader.h']]],
  ['is_5fplayer_960',['IS_PLAYER',['../game__reader_8h.html#a8633d96cdc0edc3e9ba01fe0b1592815a8f4f8088f243a7edbf1b8a99044ceea3',1,'game_reader.h']]],
  ['is_5fspace_961',['IS_SPACE',['../game__reader_8h.html#a8633d96cdc0edc3e9ba01fe0b1592815a6741084272d491bdabdcb9940a30af3f',1,'game_reader.h']]]
];

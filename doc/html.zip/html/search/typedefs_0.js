var searchData=
[
  ['area_930',['Area',['../libscreen_8h.html#acfdfc42f6522d75fa3c16713afde8127',1,'libscreen.h']]]
];
